package generalmedicalhistory;

public class GeneralMedicalHistory
{

}
