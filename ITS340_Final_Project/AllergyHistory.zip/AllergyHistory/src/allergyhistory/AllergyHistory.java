package allergyhistory;

public class AllergyHistory {

}
